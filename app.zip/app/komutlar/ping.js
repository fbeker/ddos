const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    
   var pingi = ''
        if(bot.ping >= "100") {
            var pingi = 'Suri suri bum bum'
        }    
     if(bot.ping < "70") {
            var pingi = 'Ping stabil, hizmet tam "⌣"'
        }    
  if(bot.ping < "5") {
            var pingi = 'Tabii olm uzaydan bağlanıyoruz ಠ⌣ಠ'
        }    
  if(bot.ping >= "200") {
            var pingi = 'Hmm, sence de normal mi :}'
        }
 if(bot.ping >= "500") {
            var pingi = 'Pingim fazla, fakat cevaplara hazırım :3'
        } 
 if(bot.ping >= "1000") {
            var pingi = 'Suriyeden bağlanıyom'
        } 
 if(bot.ping >= "5000") {
            var pingi = 'TTNET LOVER'
        } 


    

    let msgping1 = new Date();

    let botping = new Date() - message.createdAt;

    let msgping2 = new Date() - msgping1;

    let pingembed = new Discord.RichEmbed()
        .setColor("RANDOM")
        .addField('<:genel:576465035388256358> API Ping : ', Math.floor(bot.ping) + 'ms')
        .addField('<:oyun:576465035203837962> Bot Ping : ', Math.floor(botping) + 'ms')
        .addField('<:eglence:576465034893459476> Mesaj Pingi : ', '~' + Math.round(msgping2) + 'ms')
        .setFooter(`Ping Durumu; ` + `${pingi}` + ``);

        
    return message.channel.send(pingembed);
        

};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["pong", "pingi"],
  permLevel: 0
};

exports.help = {
  name: 'ping',
  description: 'Botun pingini gösterir.',
  usage: 'ping'
};