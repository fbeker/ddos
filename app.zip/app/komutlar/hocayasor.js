const Discord = require('discord.js');

const nihatreyizincevapları = [
    "Hayır, günah değildir.",
    "Evet, günahtır.",
    "Cümleten inşallah!",
    "Allah bilir...",
    "Su içip gelicem! *boğulur*",
    "Caizdir yavrum, caizdir!"
];

exports.run = function(client, message, args) {
    var hojam = args.join(' ');

    var zemzem = nihatreyizincevapları[Math.floor(Math.random() * nihatreyizincevapları.length)];

    if(!hojam) return message.reply('Bir soru belirt. **Doğru Kullanım**: <prefixiniz>hocayasor <soru>')
    else message.channel.send(zemzem)

};  

exports.conf = {
  enabled: true, 
  guildOnly: true, 
  aliases: [],
  permLevel: 0 
};

exports.help = {
  name: 'hocayasor', 
  description: 'Nihat Hatipoğlu sorularınızı cevaplar.',
  usage: 'hocayasor <soru>'
};