const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, params) => {
  
   const embed = new Discord.RichEmbed()
   .setColor("RANDOM")
   .setThumbnail(client.user.avatarURL, true)
   .addField('<a:gold:577928898289860634> `/yetkili`', '➠ **Bot Hakkında Komutları Gösterir**.')
   .addField('<:eglence:576465034893459476> `/eğlence`', '➠ **Sunucu Hakkında Komutlarını Gösterir**.')
   .addField('<:oyun:576465035203837962> `/ekstra`', '➠ **Ekstra Komutları Gösterir**.')
   .addField('<:muzik:576465039809052751> `/müzik`', '➠ **Eğlence Komutlarını Gösterir**.')
   .addField('<:kullanci:576465039389753359> `/kullanıcı`', '➠ **Herkesin Kullana Bileceği Komutları Gösterir**.')
   .addField(`» Linkler`, `[Bot Davet Linki](https://discordapp.com/oauth2/authorize?client_id=401732244084883458&scope=bot&permissions=2146958847) **|** [Destek Sunucusu](https://discord.gg/j5U4CjV) **|** [Website](https://trux-bot.glitch.me/)`)
   message.channel.send({embed});
  
 };
 exports.conf = {
  enabled: true,
  aliases: [],
  permLevel: 0, 
};

exports.help = {
  name: "yardım",
  description: "Gerekli komutları gösterir.",
  usage: "yardım"
};