const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, params) => {
  
  let prefix = ayarlar.prefix
 
  if (!params[0]) {
    message.channel.sendCode("asciidoc",`= Trux Ekstra Yardım Menüsü =


🖥${prefix}ping            ::  Pinginizi Gösterir.
🖥${prefix}servericon      ::  Sunucunun Resmini Gönderir.
🖥${prefix}sunucubilgi     ::  Sunucunun Bilgilerini Gösterir.
🖥${prefix}top10           ::  Botun Bulunduğu En Çok Kişiye Sahip Olan 10 Sunucuyu Gösterir.



Komutlar hakkında yardım almak icin ${prefix}ekstra <komut ismi>`);
  } else {
    let command = params[0];
    if (client.commands.has(command)) {
      command = client.commands.get(command);
      message.channel.sendCode('asciidoc', `= ${command.help.name} =

Hakkında  :: ${command.help.description}
Kullanım  :: ${prefix}${command.help.usage}`);
    }
  }
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['Ekstra','extra','Extra'],
  permLevel: 2
};

exports.help = {
  name: 'ekstra',
  description: 'Ekstra Komutları Gösterir.',
  usage: 'ekstra'
}; 