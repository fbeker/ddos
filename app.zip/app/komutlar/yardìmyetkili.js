const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, params) => {
  
  let prefix = ayarlar.prefix
 
  if (!params[0]) {
    message.channel.sendCode("asciidoc",`= Trux Yetkili Yardım Menüsü =


💎 ${prefix}ban             ::  Belirttiğiniz Kullanıcıyı Banlarsınız.
💎 ${prefix}unban           ::  Belirttiğiniz Kullanıcının Banını Kaldırırsınız.
💎 ${prefix}banliste        ::  Banlanan Kişileri Gösterir.
💎 ${prefix}kick            ::  Belirttiğiniz Kullanıcıyı Kickler.
💎 ${prefix}yavaşmod        ::  Bir Kanala Slowmode Koyarsınız.
💎 ${prefix}giveaway        ::  Süreli Çekiliş Yapabilirsiniz.
💎 ${prefix}uyar            ::  Belirttiğiniz Kullanıcıyı Uyarırsınız.
💎 ${prefix}temizle         ::  Mesajları Temizler.
💎 ${prefix}yaz             ::  Bota Yazdığınız Mesajı Yazdırırsınız.
💎 ${prefix}oylama          ::  Oylama Başlatırsınız.
💎 ${prefix}reklamengelle   ::  Reklam Engellemeyi Açarsınız.
💎 ${prefix}küfürengelle    ::  Küfür Engellemeyi Açarsınız.
💎 ${prefix}sayaç           ::  Sunucuya Girenlen Kullanıcıları Sayar.
💎 ${prefix}otorol          ::  Sunucuya Giren Kullanıcılara Otomatik Rol Verir.
💎 ${prefix}prefix          ::  Bot'un Ön Ekini Değiştirir.
💎${prefix}özelkomutekle   ::  Özel Komut Ekleminizi Sağlar.


Komutlar hakkında yardım almak icin ${prefix}yetkili <komut ismi>`);
  } else {
    let command = params[0];
    if (client.commands.has(command)) {
      command = client.commands.get(command);
      message.channel.sendCode('asciidoc', `= ${command.help.name} =

Hakkında  :: ${command.help.description}
Kullanım  :: ${prefix}${command.help.usage}`);
    }
  }
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['Yetkili','moderatör','moderator'],
  permLevel: 0
};

exports.help = {
  name: 'yetkili',
  description: 'Yetkili Komutlarını Gösterir.',
  usage: 'yetkili'
}; 