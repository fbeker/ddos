const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, params) => {
  
  let prefix = ayarlar.prefix
 
  if (!params[0]) {
    message.channel.sendCode("asciidoc",`= Trux Kullanıcı Yardım Menüsü =


🏆${prefix}canlıdestek     ::  Botun Yapımcılarından Destek Alırsınız.
🏆${prefix}davet           ::  Botu Davet Eder.
🏆${prefix}yetkilerim      ::  Yetkilerinizi Gösterir.
🏆${prefix}roller          ::  Sunucuda Bulunan Rolleri Gösterir.
🏆${prefix}tavsiye         ::  Bot İçin Tavisye Verir.
🏆${prefix}fortnite        ::  Fortnite Oyuncu İstatistik Gösterme.
🏆${prefix}kullanıcıbilgi  ::  Bilgilerinizi Gösterir. 
🏆${prefix}döviz           ::  Döviz Fiyatlarını Gösterir.
🏆${prefix}emojiler        ::  Sunucu'da Olan Emojileri Gösterir.


Komutlar hakkında yardım almak icin ${prefix}eğlence <komut ismi>`);
  } else {
    let command = params[0];
    if (client.commands.has(command)) {
      command = client.commands.get(command);
      message.channel.sendCode('asciidoc', `= ${command.help.name} =

Hakkında  :: ${command.help.description}
Kullanım  :: ${prefix}${command.help.usage}`);
    }
  }
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['Kullanıcı','user','User'],
  permLevel: 0
};

exports.help = {
  name: 'kullanıcı',
  description: 'Kullanıcı Komutlarını Gösterir.',
  usage: 'kullanıcı'
}; 