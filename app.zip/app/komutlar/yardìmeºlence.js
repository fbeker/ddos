const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, params) => {
  
  let prefix = ayarlar.prefix
 
  if (!params[0]) {
    message.channel.sendCode("asciidoc",`= Trux Eğlence Yardım Menüsü =


🥅${prefix}8ball           ::  Bota Soru Sorarsınız
🥅${prefix}avatar          ::  Belirttiğiniz Kullanıcıyı Korkutursunuz
🥅${prefix}emojiyazı       ::  Yazınızı Emoji Yazısına Çevirir
🥅${prefix}atatürk         ::  Atatürk Resmi Gönderir
🥅${prefix}google          ::  Google da Söylediğiniz Yazıyı Aratır
🥅${prefix}sarıl           ::  Belirttiğiniz Kullanıcıya Sarılırsınız
🥅${prefix}woodie          ::  Woodie Hakkında Bilgi Verir
🥅${prefix}slots           ::  Slots Oynarsınız
🥅${prefix}stres-çarkı     ::  Stres Çarkı Döndürürsünüz
🥅${prefix}slots           ::  Slots Oynarsınız
🥅${prefix}hesapla         ::  Yazdığınız Soruyu Hesaplar
🥅${prefix}yazıtura        ::  Yazı Tura Oynarsınız



Komutlar hakkında yardım almak icin ${prefix}eğlence <komut ismi>`);
  } else {
    let command = params[0];
    if (client.commands.has(command)) {
      command = client.commands.get(command);
      message.channel.sendCode('asciidoc', `= ${command.help.name} =

Hakkında  :: ${command.help.description}
Kullanım  :: ${prefix}${command.help.usage}`);
    }
  }
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['e','fun','eğlenme'],
  permLevel: 0
};

exports.help = {
  name: 'eğlence',
  description: 'Eğlence Komutlarını Gösterir.',
  usage: 'eğlence'
}; 